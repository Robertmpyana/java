import io.cucumber.java.en.Given;
        import io.cucumber.java.en.When;
        import io.cucumber.java.en.Then;
        import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
        import org.openqa.selenium.WebElement;
        import org.openqa.selenium.chrome.ChromeDriver;
        import java.util.List;
        import static org.junit.Assert.assertEquals;
        import static org.junit.Assert.assertFalse;
        import static org.junit.Assert.assertTrue;

        public class uiMovieStepDefinitions {
            WebDriver driver;

            @Given("I am on the Localhost website")
            public void navigateToSwapi() throws InterruptedException {
                System.setProperty("webdriver.chrome.driver", "C:\\JavaAssessment\\src\\main\\resources\\Drivers\\chromedriver.exe");
                driver = new ChromeDriver();
                driver.get("http://localhost:3000/");
                Thread.sleep( 5500 );
            }

            @When("I sort movies by Title")
            public void sortMoviesByTitle() {
              //  WebElement sortDropdown = driver.findElement(By.xpath("//select[@id='sort-dropdown']"));
                WebElement sortDropdown = driver.findElement(By.xpath("//th[contains(text(),'Title')]"));
                sortDropdown.click();
              /*  WebElement titleOption = driver.findElement(By.xpath("//th[contains(text(),'Title')]"));
                titleOption.click();*/
            }

            @Then("the last movie in the list should be {string}")
            public void verifyLastMovie(String expectedLastMovie) throws InterruptedException {
                Thread.sleep( 5500 );
                List<WebElement> movieTitles = driver.findElements(By.xpath("//a[contains(text(),'The Phantom Menace')]"));
                WebElement lastMovieTitleElement = movieTitles.get(movieTitles.size() - 1);
                String lastMovieTitle = lastMovieTitleElement.getText();
                assertEquals(expectedLastMovie, lastMovieTitle);
            }

            @When("I view the details of the movie {string}")
            public void viewMovieDetails(String movieTitle) throws InterruptedException {
                WebElement movieLink = driver.findElement(By.xpath("//a[contains(text(),'The Empire Strikes Back')]"));
                movieLink.click();
                Thread.sleep(2000);
            }

            @Then("the Species list should contain {string}")
            public void verifySpeciesList(String expectedSpecies) throws InterruptedException {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollBy(0,450)");
                Thread.sleep(3000);
                WebElement speciesList = driver.findElement(By.xpath("//li[contains(text(),'Wookie')]"));
                String speciesText = speciesList.getText();
                assertTrue(speciesText.contains(expectedSpecies));
            }

            @When("I check if the planet {string} is part of the movie {string}")
            public void checkPlanetInMovie(String planet, String movieTitle) throws InterruptedException {

                WebElement movieLink = driver.findElement(By.xpath("//a[contains(text(),'The Phantom Menace')]"));
                movieLink.click();
                Thread.sleep(1500);
            }

            @Then("{string} should not be part of the movie")
            public void verifyPlanetNotPartOfMovie(String planet) {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("window.scrollBy(0,450)");
                WebElement planetsList = driver.findElement(By.xpath("//li[contains(text(),'Camino')]"));
                String planetsText = planetsList.getText();
                assertFalse(planetsText.contains(planet));
            }

        }
