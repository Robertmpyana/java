
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;

    public class apiMovieStepDefinitions {

        private Response response;

        @Given("I get the list of movies")
        public void getListOfMovies() {
            response = given().get("https://swapi.dev/api/films/");
        }

        @Then("I verify the count of movies is {int}")
        public void verifyMovieCount(int expectedCount) {
            int actualCount = response.jsonPath().getList("results").size();
            assertEquals(expectedCount, actualCount);
            System.out.println("the count is: " + actualCount);
        }

        @Given("I get the {int}rd movie details")
        public void getNthMovieDetails(int movieIndex) {
            response = given().get("https://swapi.dev/api/films/" + movieIndex + "/");
        }

        @Then("I verify the director is {string}")
        public void verifyDirector(String expectedDirector) {
            String actualDirector = response.jsonPath().getString("director");
            assertEquals(expectedDirector, actualDirector);
            System.out.println("the director is: " + actualDirector);
        }

        @Given("I get the {int}th movie details")
        public void getNthMovieDetailsOrdinal(int movieIndex) {
            response = given().get("https://swapi.dev/api/films/" + movieIndex + "/");
        }

        @Then("I verify the producers are not {string}")
        public void verifyProducers(String notExpectedProducers) {
            String actualProducers = response.jsonPath().getString("producers");
            String[] expectedProducers = notExpectedProducers.split(", ");
            for (String producer : expectedProducers) {
                assertFalse(actualProducers.contains(producer));
                System.out.println("actual producer: " + actualProducers);
            }
        }
    }


