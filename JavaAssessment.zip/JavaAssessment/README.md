To run the project:
1. clone the project from the repo (mvn clone then link of the code) using Intellij IDEA
2. On the IDEA - load the project with Maven buld, install the required dependencies (mvn clean install)
3. For API- go navigate to the apimovies.feature and right click it to run it
4. For UI- you will need to start the framework from this repo.  (https://github.com/MindfulMichaelJames/star-wars/tree/main).
 then run yarn start/ npm start
5. then open > start

- Local:        http://localhost:3000
after navigate to uiMovies.feature and run it